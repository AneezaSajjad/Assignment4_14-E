import javafx.fxml.FXML;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UnitTest {
    Connection con ;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String UserID,accountNumber;
    private void withDrawCash(String accountNo,int NewBalance) throws SQLException {
        ps = con.prepareStatement("UPDATE Bank_Account SET Balance =? WHERE Account_No = '" + accountNo+ "'");
        ps.setInt(1, NewBalance);
        ps.executeUpdate();
    }

    public int add(int a, int b){
        return  a+b;
    }
    public void hello(){

    }
    public boolean updatePayStatus(String loanID,String loanAmount,String accountNumber) throws SQLException {
       try {
           if(Integer.parseInt(loanAmount) < 5000){
               return false;
           }
           if(Integer.parseInt(loanAmount) > 30000){
               return false;
           }       }
       catch (Exception e){
           return false;
       }

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String todayDate = formatter.format(date);
        formatter = new SimpleDateFormat(" HH:mm:ss");
        String time = formatter.format(date);
        con = DbConnection.Connection();
        ps = con.prepareStatement("SELECT * FROM Loan_History WHERE Loan_ID = ?");
        ps.setString(1, loanID);
        rs = ps.executeQuery();
        boolean bool = false;
        if(rs.next()){
            System.out.println(rs.getString("Status"));
            if(!rs.getString("Status").equals("Pending")){
                bool = true;
            }
        }
        if(bool){

            con.close();
            rs.close();
            return false;
        }
        bool = false;
        ps = con.prepareStatement("SELECT * FROM Bank_Account WHERE Account_No = ?");
        ps.setString(1, accountNumber);
        rs = ps.executeQuery();
        if (rs.next()) {
            int NewBalance = (rs.getInt("Balance") - Integer.parseInt(loanAmount));
            if (NewBalance >= 0) {
                withDrawCash(accountNumber, NewBalance);
            } else {
                bool = true;
            }
            if(bool){
                con.close();
                rs.close();
                return false;
            }
            System.out.println(loanID);
            ps = con.prepareStatement("UPDATE Loan_History set Status = 'Paid', Loan_Return_Date = ? ,Loan_Return_Time =? where Loan_ID = ?");
            ps.setString(3, loanID);
            ps.setString(1, todayDate);
            ps.setString(2, time);

            ps.executeUpdate();
            ps.close();
            rs.close();
            con.close();
            return true;
        }
        return  false;
    }
    private void addToLoanHistory(String id,String status) throws SQLException {
        con = DbConnection.Connection();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        String todayDate = formatter.format(date);
        formatter = new SimpleDateFormat(" HH:mm:ss");
        String time = formatter.format(date);
        int loanID = 0;
        ps = con.prepareStatement("SELECT * FROM Loan_History");
        rs = ps.executeQuery();
        while (rs.next()){
            loanID = rs.getInt("Loan_ID");
        }

        PreparedStatement ps = con.prepareStatement("INSERT INTO Loan_History VALUES (?,?,?,?,?,?,?)");
        ps.setInt(1, (loanID + 1));
        ps.setString(2, id);
        ps.setString(3, status);
        ps.setString(4, todayDate);
        ps.setString(5, time);
        ps.setString(6, "-");
        ps.setString(7, "-");
        ps.executeUpdate();
        rs.close();
        ps.close();

        con.close();

    }
    public boolean updateAcceptStatus(String loanID) throws SQLException {
        con = DbConnection.Connection();
        ps = con.prepareStatement("SELECT * FROM Loan_Requests WHERE Request_ID = ?");
        ps.setString(1, loanID);
        rs = ps.executeQuery();
        boolean bool = false;
        if(rs.next()){
            if(!rs.getString("Status").equals("-")){
                bool = true;

            }
        }
        if(bool){
            con.close();
            rs.close();
            return false;
        }
        ps = con.prepareStatement("UPDATE Loan_Requests set Status = 'A' where Request_ID = ?");
        ps.setString(1, loanID);
        ps.executeUpdate();
        ps.close();
        con.close();
        rs.close();
        addToLoanHistory(loanID,"Pending");
        return  true;

    }
    public boolean updateRejectStatus(String loanID) throws SQLException {
        con = DbConnection.Connection();
        ps = con.prepareStatement("SELECT * FROM Loan_Requests WHERE Request_ID = ?");
        ps.setString(1, loanID);
        rs = ps.executeQuery();
        boolean bool = false;
        if(rs.next()){
            if(!rs.getString("Status").equals("-")){
                bool = true;

            }
        }
        if(bool){
            con.close();
            rs.close();
            return false;
        }
        ps = con.prepareStatement("UPDATE Loan_Requests set Status = 'R' where Request_ID = ?");
        ps.setString(1, loanID);
        ps.executeUpdate();
        ps.close();
        con.close();
        rs.close();

        return true;
    }
    public boolean updateLoanRequestStatus(String amount,String reason,String accountNumber) throws SQLException {
        if(reason.isEmpty()){
            return false;
        }
        if(reason.length() < 15){
            return false;
        }
        if(reason.length() >25){
            return false;
        }
        try {
            if(Integer.parseInt(amount) < 5000){
                return false;
            }
            if(Integer.parseInt(amount) > 30000){
                return false;
            }       }
        catch (Exception e){
            return false;
        }
        boolean bool = false;
        if (amount.isEmpty()|| reason.isEmpty()) {
        }
        else{
            if(Integer.parseInt(amount)<0){
                bool =  true;
            }
            if(bool){
                con.close();
                ps.close();
                rs.close();
                return false;
            }
            con = DbConnection.Connection();
            ps = con.prepareStatement("SELECT * FROM Loan_Requests WHERE Account_No = ?");
            ps.setString(1, accountNumber);
            rs = ps.executeQuery();
            bool = false;
            while(rs.next()){
                if(rs.getString("Status").equals("-")){
                    bool = true;
                }
            }
            if(bool){
                con.close();
                rs.close();
                return false;
            }
            rs.close();
            ps.close();

            ps = con.prepareStatement("SELECT h.Loan_ID,h.Status,l.Amount FROM Loan_History h, Loan_Requests l where l.Request_ID = h.Request_ID and l.Account_No = '"+accountNumber+"'");
            rs = null;

            rs = ps.executeQuery();
            bool = false;
            while(rs.next()){
                if(rs.getString("Status").equals("Pending")){
                    bool = true;
                }                }
            if(bool){
                con.close();
                rs.close();
                return false;
            }
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            Date date = new Date();
            String todayDate = formatter.format(date);
            formatter = new SimpleDateFormat(" HH:mm:ss");
            String time = formatter.format(date);
            int requestId = 0;
            ps = con.prepareStatement("SELECT * FROM Loan_Requests");
            rs = ps.executeQuery();
            while (rs.next()){
                requestId = rs.getInt("Request_ID");
            }
            PreparedStatement ps = con.prepareStatement("INSERT INTO Loan_Requests VALUES (?,?,?,?,?,?,?)");
            ps.setInt(1, (requestId + 1));
            ps.setString(2, accountNumber);
            ps.setString(3, amount);
            ps.setString(4, reason);
            ps.setString(5, "-");
            ps.setString(6, todayDate);
            ps.setString(7, time);
            ps.executeUpdate();
            return true;
        }
        return  false;
    }


}
