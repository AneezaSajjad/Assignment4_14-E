import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.Assert.*;

public class UnitTestTest {
    Connection con ;
    PreparedStatement ps = null;
    ResultSet rs = null;
    @Test
    void updatePayStatus() throws SQLException {
    UnitTest test = new UnitTest();
    //test.updatePayStatus("3","10000","0-7443-5353");
        //our company policy is that we donot accept loan below 5000 and above 30000
        // so our valid range for amount is 5000 - 30000
        //boundary conditions (4999 - 5000 -5001   29999 - 30000 -30001)
        //our class is only integer
        //here there is not equivalence class for account No, becuase it can never be false its given in such a way in original code
        // so only testing would be done for amount of loan.
        assertEquals(false,test.updatePayStatus("3","15000.32","0-7443-5353")); //user donot have any money to pay

        assertEquals(false,test.updatePayStatus("3","adsasd","0-7443-5353"));
        assertEquals(false,test.updatePayStatus("3","4999","0-7443-5353"));
        assertEquals(true,test.updatePayStatus("3","5000","0-7443-5353"));
        assertEquals(false,test.updatePayStatus("3","5001","0-7443-5353")); //false because if you pay once you cannot pay again, we already have paid.
        assertEquals(false,test.updatePayStatus("3","29999","0-7443-5353"));
        assertEquals(false,test.updatePayStatus("3","30000","0-7443-5353"));
        assertEquals(false,test.updatePayStatus("3","30001","0-7443-5353"));

    }


    @Test
    void updateRejectStatus() throws SQLException {
        UnitTest test2 = new UnitTest();
        // to be note that we only have range in true and false, because the loan ID is given in such a way in original program that it can never be wrong.
        assertEquals( true,test2.updateRejectStatus("5"));
        assertEquals( false,test2.updateRejectStatus("5")); //becuase once rejected cannot be reaccepted again


    }
    @Test
    void updateAcceptStatus() throws SQLException {
        UnitTest test2 = new UnitTest();
        // to be note that we only have range in true and false, because the loan ID is given in such a way in original program that it can never be wrong.

        assertEquals( true,test2.updateAcceptStatus("6"));
        assertEquals( false,test2.updateAcceptStatus("6")); //becuase once accepted cannot be reaccepted again
    }
    @Test
    void updateLoanRequestStatus() throws SQLException {
        UnitTest test = new UnitTest();
    //there is only 1 true case becuase once you update any value you cannot re-update it, just to avoid redundancy
        //in this case once we request we cannot request again unless we pay the loan
        //our company policy is that we donot accept loan below 5000 and above 30000
        // so our valid range for amount is 5000 - 30000
        //boundary conditions (4999 - 5000 -5001   29999 - 30000 -30001)
        //our True Equivalence class is only integer

        // for reason; miminum length of reason is 15 chracters, and at max 25 characters
        // so our boundary condition is a string of lengthy 14 15 16 chracters  24 25 26 characters

        //here there is not equivalence class for account No, becuase it can never be false its given in such a way in original code
        // so only testing would be done for amount of loan and reason.
        assertEquals(false, test.updateLoanRequestStatus("15000.32", "helloooooooooo", "0-7443-5353"));//14 char
        assertEquals(false, test.updateLoanRequestStatus("adsasd", "", "0-7443-5353"));
        assertEquals(false, test.updateLoanRequestStatus("4999", "", "0-7443-5353"));
        assertEquals(true, test.updateLoanRequestStatus("5000", "hellooooooooooo", "6-1234-7000")); //15char
        assertEquals(false, test.updateLoanRequestStatus("5001", "helloooooooooooo", "0-7443-5353")); //16 char
        assertEquals(false, test.updateLoanRequestStatus("29999", "helloooooooooooooooooooo", "0-7443-5353")); //24 char
        assertEquals(false, test.updateLoanRequestStatus("30000", "hellooooooooooooooooooooo", "0-7443-5353")); //25 char
        assertEquals(false, test.updateLoanRequestStatus("30001", "helloooooooooooooooooooooo", "0-7443-5353")); //26 char
        //false because if request, and the request isn't approved you cannot request the loan, or if any loan isn't paid you cannot request new loan

        //there may be some valid classes donot get accepted its only due the reason that other checks come in action, like loan not already paid and those one,
        // //but you can see from the function that the check are implemented correctly
    }

}